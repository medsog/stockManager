package com.concretepage.entity;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="articles")
public class Article implements Serializable { 
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="article_id")
    private int articleId;  
	@Column(name="article_code")
    private int articleCode;
	@Column(name="marque")
    private String marque;
	@Column(name="description")
    private String description;
	@Column(name="taille")
    private String taille;
	@Column(name="couleur")
    private String couleur;
	@Column(name="prix_achat")
    private double prixAchat;
	@Column(name="prix_vente")
    private double prixVente;
	@Column(name="frais_transport")
    private double fraisTransport;
		
	
	public int getArticleId() {
		return articleId;
	}
	public void setArticleId(int articleId) {
		this.articleId = articleId;
	}
	public int getArticleCode() {
		return articleCode;
	}
	public void setArticleCode(int articleCode) {
		this.articleCode = articleCode;
	}
	public String getMarque() {
		return marque;
	}
	public void setMarque(String marque) {
		this.marque = marque;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getTaille() {
		return taille;
	}
	public void setTaille(String taille) {
		this.taille = taille;
	}
	public String getCouleur() {
		return couleur;
	}
	public void setCouleur(String couleur) {
		this.couleur = couleur;
	}
	public double getPrixAchat() {
		return prixAchat;
	}
	public void setPrixAchat(double prixAchat) {
		this.prixAchat = prixAchat;
	}
	public double getPrixVente() {
		return prixVente;
	}
	public void setPrixVente(double prixVente) {
		this.prixVente = prixVente;
	}
	public double getFraisTransport() {
		return fraisTransport;
	}
	public void setFraisTransport(double fraisTransport) {
		this.fraisTransport = fraisTransport;
	}
	
} 