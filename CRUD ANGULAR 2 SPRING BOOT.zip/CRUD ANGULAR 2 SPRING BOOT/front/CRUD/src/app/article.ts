export class Article {
   constructor(public articleId: string ,public articleCode: number,
  public marque: string,
  public description: string,
  public taille: string,
  public couleur: string,
  public prixAchat: number,
  public prixVente: number,
  public fraisTransport: number) {
   }
}
