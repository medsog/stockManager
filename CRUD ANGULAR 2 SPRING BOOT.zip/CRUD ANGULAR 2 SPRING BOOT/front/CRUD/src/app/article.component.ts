import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

import { ArticleService } from './article.service';
import { Article } from './article';

@Component({
   selector: 'app-article',
   templateUrl: './article.component.html',
   styleUrls: ['./article.component.css']
})
export class ArticleComponent implements OnInit {
   //Component properties
   allArticles: Article[];
   statusCode: number;
   requestProcessing = false;
   articleIdToUpdate = null;
   processValidation = false;
   //Create form
   articleForm = new FormGroup({
       code: new FormControl('', Validators.required),
       marque: new FormControl(''),
       description: new FormControl('', Validators.required),
       taille: new FormControl('', Validators.required),
       couleur: new FormControl('', Validators.required),
       prixAchat: new FormControl('', Validators.required),
       prixVente: new FormControl('', Validators.required),
       fraisTransport: new FormControl('')
   });
   //Create constructor to get service instance
   constructor(private articleService: ArticleService) {
   }
   //Create ngOnInit() and and load articles
   ngOnInit(): void {
	   this.getAllArticles();
   }
   //Fetch all articles
   getAllArticles() {
        this.articleService.getAllArticles()
		  .subscribe(
                data => this.allArticles = data,
                errorCode =>  this.statusCode = errorCode);
   }
   //Handle create and update article
   onArticleFormSubmit() {
	  this.processValidation = true;
	  if (this.articleForm.invalid) {
	       return; //Validation failed, exit from method.
	  }
	  //Form is valid, now perform create or update
      this.preProcessConfigurations();
	  let code = this.articleForm.get('code').value;
      let marque = '' ;//this.articleForm.get('marque').value;
     let descriprtion = this.articleForm.get('description').value;
     let taille = this.articleForm.get('taille').value;
     let couleur = this.articleForm.get('couleur').value;
     let prixAchat = this.articleForm.get('prixAchat').value;
     let prixVente = this.articleForm.get('prixVente').value;
     let fraisTransport = 0 ;// this.articleForm.get('fraisTransport').value;


     if (this.articleIdToUpdate === null) {
	    //Handle create article
	    let article= new Article(null, code, marque,descriprtion,taille,couleur,prixAchat,prixVente,fraisTransport);
	    this.articleService.createArticle(article)
	      .subscribe(successCode => {
		            this.statusCode = successCode;
				    this.getAllArticles();
					this.backToCreateArticle();
			    },
		        errorCode => this.statusCode = errorCode);
	  } else {
   	    //Handle update article
	    let article= new Article(this.articleIdToUpdate, code, marque,descriprtion,taille,couleur,prixAchat,prixVente,fraisTransport);
	    this.articleService.updateArticle(article)
	      .subscribe(successCode => {
		            this.statusCode = successCode;
				    this.getAllArticles();
					this.backToCreateArticle();
			    },
		        errorCode => this.statusCode = errorCode);
	  }
   }
   //Load article by id to edit
   loadArticleToEdit(articleId: string) {
      this.preProcessConfigurations();
      this.articleService.getArticleById(articleId)
	      .subscribe(article => {
		            this.articleIdToUpdate = article.articleId;
		            this.articleForm.setValue({ code: article.articleCode, marque: article.marque, description: article.description, taille: article.taille, couleur: article.couleur, prixAchat: article.prixAchat, prixVente: article.prixVente, fraisTransport: article.fraisTransport });
					this.processValidation = true;
					this.requestProcessing = false;
		        },
		        errorCode =>  this.statusCode = errorCode);
   }
   //Delete article
   deleteArticle(articleId: string) {
      this.preProcessConfigurations();
      this.articleService.deleteArticleById(articleId)
	      .subscribe(successCode => {
		            this.statusCode = successCode;
				    this.getAllArticles();
				    this.backToCreateArticle();
			    },
		        errorCode => this.statusCode = errorCode);
   }
   //Perform preliminary processing configurations
   preProcessConfigurations() {
      this.statusCode = null;
	  this.requestProcessing = true;
   }
   //Go back from update to create
   backToCreateArticle() {
      this.articleIdToUpdate = null;
      this.articleForm.reset();
	  this.processValidation = false;
   }


  /**
   * Methodes Onchange des input
   */

  codeOnchange(e){}
  descriptionOnchange(e){}
  tailleOnchange(e){}
  couleurOnchange(e){}
  prixAchatOnchange(e){}
  prixVenteOnchange(e){}
}
